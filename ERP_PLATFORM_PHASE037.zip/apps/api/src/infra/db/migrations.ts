import { existsSync, readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

/**
 * Migration manifest (MIGRATION_STRATEGY §1): the ordered `NNNN_description`
 * tags mirror `apps/api/migrations/meta/_journal.json` and the SQL files on
 * disk. `/health/ready` compares `erp.schema_version()` (upserted by every
 * migration) against this list; a stale build against a newer schema fails
 * readiness. The unit test `migrations.spec.ts` asserts manifest ↔ journal ↔
 * files never drift.
 *
 * Convention: every `NNNN_*.sql` must upsert
 * `INSERT INTO erp._schema_state (key, value) VALUES ('schema_version', N)`
 * with its own number — enforced by the same unit test.
 */
export const MIGRATIONS: readonly string[] = [
  "0001_core_infra",
  "0002_rls_macro",
  "0003_identity_core",
  "0004_permissions_seed",
  "0005_system_role_templates_seed",
  "0006_tenancy_provisioning",
  "0007_accounts_schema",
  "0008_platform_seeds",
  "0009_partners_items",
  "0010_accounting_core",
  "0011_journal_tables",
  "0012_treasury",
  "0013_tax",
  "0014_inventory_core",
  "0015_inventory_tracking",
  "0016_purchasing_core",
  "0017_purchasing_ap",
  "0018_sales_core",
  "0019_sales_ar",
  "0020_reporting_core",
  "0021_subscriptions_billing",
  "0022_industry_configuration",
  "0023_notifications_categories",
  "0024_pos_core",
  "0025_automotive_distribution",
  "0026_manufacturing",
  "0027_crm_projects",
  // PHASE-019 T48 (the recorded deviation — agent-ctx/T48-7-service-orders.md):
  // 0027 missed the stock_reservations.holder_type widening for
  // SERVICE_ORDER holders (0025 gave JOB_CARD its counterpart in the same
  // migration that created job_cards); this re-issues the CHECK with
  // 'SERVICE_ORDER' added. Additive only — see 0028_crm_service_order_holder.sql.
  "0028_crm_service_order_holder",
  // PHASE-020 (MASTER-PLAN §3): the offline synchronization foundation —
  // tombstones + inbox_commands (tenant-owned, RLS), device_refresh_tokens
  // (the sessions pattern), the devices registry widening, the
  // sales_invoices owner-device stamp, the sync permission re-assertions
  // and the offline.* plan grants. See 0029_sync_foundation.sql.
  "0029_sync_foundation",
  // PHASE-020 T5 (the substrate fix, agent-ctx/T-P20-2a-pull.md): 0024
  // granted erp_app INSERT on change_log but missed USAGE on its bigserial
  // sequence change_log_seq_seq — the feed writers could never append as
  // erp_app. Additive grant only. See 0030_sync_change_log_sequence_grant.sql.
  "0030_sync_change_log_sequence_grant",
  // PHASE-020 T9 (SYNC_PROTOCOL §6.2 aggregate snapshots): the sync
  // update_draft handler replaces DRAFT invoice lines wholesale
  // (DELETE + re-INSERT); 0018 never granted DELETE (online drafts are
  // append-only). DRAFT-only by handler discipline + OWNER_DEVICE_WINS
  // single-writer. See 0031_sync_draft_line_replace.sql.
  "0031_sync_draft_line_replace",
  // PHASE-021 DR-P21-01 (MASTER-PLAN §1 item 2): devices.device_key_hash
  // relaxed to nullable — the one-time enrollment proof's "consumed" state
  // is NULL (POST /api/v1/devices/:id/enroll clears it on success).
  // Backward compatible: every existing writer still provides a hash.
  // See 0032_device_enrollment_one_time.sql.
  "0032_device_enrollment_one_time",
  // PHASE-022 DR-P22-05a (MASTER-PLAN §1 item 5): devices.linked_partner_id —
  // the personal-account device's linked partner, the server-side partner
  // scope for the personal pull feeds (LOCAL_DATABASE §1.1 rule 2). Nullable
  // plain uuid (devices stays service-mediated — no cross-plane FK); NULL =
  // no linkage → the personal pull serves an empty partner scope (fail
  // closed). No business-schema change. See 0033_mobile_feeds.sql.
  "0033_mobile_feeds",
  // PHASE-022 DR-P22-07a (MASTER-PLAN §1 item 7): the FCM skeleton's
  // device-token opt-in store — the dedicated service-mediated table (the
  // 0029 device_refresh_tokens pattern; devices has no natural JSON column
  // for push tokens). opted_in defaults FALSE (explicit opt-in, default OFF);
  // one active row per device (uq device_id), a token never belongs to two
  // devices (uq token); revocation clears the rows. No business-schema change
  // (the DR-P22-05a reading). See 0034_device_push_tokens.sql.
  "0034_device_push_tokens",
  // PHASE-023 (external integrations): the operational e-invoicing registry
  // expansion (submissions × adapter 1:N, attempts/backoff, sealed
  // payload/response artifacts, retry sweep), the S-10 certificate store +
  // append-only usage audit (secret-store PATH only — key material lives in
  // the files module), per-tenant adapter rollout flags (default OFF), the
  // bank-statement parked lines + seeded format registry, the commerce
  // channel staging tables (natural-key upsert, server-decision conflicts),
  // and the billing payout batches (T6 reconciliation substrate). See
  // 0035_external_integrations.sql.
  "0035_external_integrations",
  // PHASE-024: 0036_security_hardening.sql (MFA policy substrate + the
  // offboarding purge path + audit-review indexes — T4/T8/T11).
  "0036_security_hardening",
  // PHASE-026: 0037_fixed_assets.sql (the fixed_assets module per DR-002
  // option A: asset_categories/assets/depreciation_runs/depreciation_lines 🔒/
  // asset_disposals/asset_revaluations + the six v2.0 CoA purposes + 13
  // permission seeds + plan/role grants + the RC-10 reconciliation kind).
  "0037_fixed_assets",
  // PHASE-027: 0038_notes_installments.sql (the notes & installments modules
  // per DR-003/ED-03 option A: notes/note_events 🔒/installment_plans/
  // installment_lines + the treasury_allocations note_id widening (the
  // settle/restore substrate) + the four v2.0 CoA purposes (1160/2150/4920/
  // 5260) + the notes.notes.return seed (0004/0005 in-phase edits) + the 12
  // feature-key plan grants + the RC-11 'NOTES' kind + the notification
  // category widening).
  "0038_notes_installments",
  // PHASE-032: 0039_education_template.sql (the education commercial shell
  // per ED-08 — configuration only: the industry_templates registry seed
  // converging the 0008 index row to the full v1.0.0 industry.education
  // manifest, the §J ar.aging report-key reconciliation; NO new tables,
  // modules, feature keys, or permission keys — the installments/notes plan
  // grants landed with 0038 already).
  "0039_education_template",
  // PHASE-033: 0040_agriculture_template.sql (the agriculture commercial
  // shell per ED-09 — configuration only: the industry_templates registry
  // seed converging the 0008 index row to the full v1.0.0
  // industry.agriculture manifest, the §J inventory.valuation report-key
  // reconciliation; NO new tables, modules, feature keys, or permission
  // keys — every required key was already granted by 0008/0026/0027, the
  // first shipped template whose REQUIRED chain needs no plan grants).
  "0040_agriculture_template",
  // PHASE-034: 0041_consolidation.sql (the consolidation module per ADR-0018
  // / DR-006 option A: consolidation_groups/group_entities/elimination_
  // entries/consolidation_runs + the consolidation_run_status §9 enum +
  // the CONSOLIDATION_ADJUSTMENT CoA template account 3220 + the 5 §3.15
  // permission seeds + the 5 feature-key plan grants + THE platform-plane
  // reader — role erp_consolidation_reader NOLOGIN BYPASSRLS, SELECT-only
  // grants on the member GL read models, and the one SECURITY DEFINER
  // reader function erp.consolidation_read_member_gl (BR-056 re-verified
  // in-function; zero cross-tenant writes at the grant level)).
  "0041_consolidation",
  // ── RESTORED LINEAGE (the pre-reset phases 028–031, recovered from
  // ERP_PLATFORM_PHASE031.zip and merged post-034): their migrations keep
  // their CONTENT byte-faithful but are renumbered to APPEND after the
  // live 0039–0041 set (application order, not phase order — every
  // migration is additive and cross-independent; on a fresh database the
  // 0001→0046 chain converges to the same end state either way). The
  // original lineage numbering was 0039_budgeting/0040_payroll/
  // 0041_industry_wholesale_electronics/0042_healthcare_claim_ref/
  // 0043_industry_healthcare → restored as 0042–0046; schema_version
  // numbers inside each file shifted accordingly (39→42, 40→43, 41→44,
  // 42→45, 43→46). ──
  // PHASE-028: 0042_budgeting.sql (the budgeting module per DR-004/ED-04
  // option A: budgets + budget_lines — versioned budgets by fiscal year &
  // scope with the BR-050 partial unique (one ACTIVE per tenant/year/scope)
  // + period-level amounts over account/cost-center/project/branch
  // dimensions; NOT ledger documents — zero journal rules, zero goldens,
  // zero CoA purposes) + the notifications category widening ('budgeting')
  // + the six §22 feature-key plan grants. §3.13 permissions pre-seeded in
  // 0004/0005 (docs-as-contract — nothing to add, drift stays 245=245).
  "0042_budgeting",
  // PHASE-029: 0043_payroll.sql (the payroll module per DR-005/ED-05,
  // financial scope only: employees (PII-restricted) + salary_structures
  // + salary_components (BR-052 versioning) + payroll_runs/run_lines 🔒
  // (INV-025 row-level totals law, one G-29 journal per run, BR-053
  // engine-only payroll accounts) + employee_loans/lines (BR-054 cap) +
  // the six CoA template purposes (2170/2180/2190/5270/5280/5295 — the
  // loan control account deliberately NOT a purpose) + the cash_movements
  // source widening ('payroll_payout', 'employee_loan' — additive) + the
  // notifications category widening ('payroll') + the eight §22
  // feature-key plan grants. §3.14 permissions pre-seeded in 0004/0005
  // with the payroll_officer role template (drift stays 245=245).
  "0043_payroll",
  // PHASE-030: 0044_industry_wholesale_electronics.sql (the first two
  // Blueprint v2.0 stage-10 industry templates per ED-06 — DATA-ONLY:
  // industry.wholesale + industry.electronics registry rows at v1.0.0,
  // the report pins reconciled to the live keys ar.aging /
  // inventory.valuation; zero new tables/columns/enums/journals/
  // permissions/plan-grants — INV-022: templates are configuration,
  // never a fork; every REQUIRED key was granted by earlier migrations
  // (notes by 0038, POS by 0024, crm.service_orders by 0027), and the
  // typed workflow-policy keys register in the code-owned POLICY_REGISTRY).
  "0044_industry_wholesale_electronics",
  // PHASE-031: 0045_healthcare_claim_ref.sql (the Healthcare Commercial
  // Shell's SINGLE schema change per ED-07 — the additive nullable
  // sales_invoices.claim_ref varchar(64), the external insurer claim
  // reference: non-null = a claim (insured) invoice billed to the
  // insurance-company partner, NULL = self-pay; plus the optional partial
  // (tenant_id, claim_ref) grouping index. No backfill, no default, RLS
  // untouched — ADR-0006 (never an official document number) + INV-022
  // (metadata that never enters a journal line)).
  "0045_healthcare_claim_ref",
  // PHASE-031: 0046_industry_healthcare.sql (the industry.healthcare
  // v1.0.0 registry seed — DATA-ONLY per the 0044 convention: the manifest
  // transcribed VERBATIM with the partners.ar_aging pin reconciled to the
  // live ar.aging key (inventory.expiry_list / notes.aging /
  // notes.maturity-calendar resolve verbatim); every REQUIRED key granted by
  // earlier migrations so the engine classifies everything LIVE, including
  // the shell's own insurance_claim_billing capability at
  // available_from_phase PHASE-031; the six typed workflow-policy keys
  // register in the code-owned POLICY_REGISTRY — zero new tables/columns/
  // enums/journals/permissions/plan-grants, INV-022).
  "0046_industry_healthcare",
  // DELIVERY COMPLETION (post-034 audit): 0047_industry_rental_logistics.sql
  // (the thirteenth — final — industry template, closing the 13-activity
  // INDUSTRY_CATALOG the blueprint documents): DATA-ONLY per the 0044/0046
  // convention — industry.rental_logistics registry row at v1.0.0, the
  // 0008 phase-019 stub converging to the full manifest; the report pins
  // reconciled to the LIVE keys inventory.serial-tracking /
  // distribution.route_visit_compliance / services.contract_revenue_schedule
  // / ar.aging; the capability set ≡ the CAPABILITY_MATRIX §1 RNT column
  // (strict both directions); zero new tables/columns/enums/journals/
  // permissions/plan-grants (INV-022; drift stays 245=245) — the deferred
  // crm.contract_deposits / crm.late_fees intake pair (RISK-019) stays
  // deferred, and the seven typed workflow-policy keys register in the
  // code-owned POLICY_REGISTRY.
  "0047_industry_rental_logistics",
  // PHASE-035 T-01 (Blueprint v3.0 · CR-05): 0048_items_import_export_grant
  // — the activation repair for audit EVAL-F-5 / H-18: the fully-built
  // PHASE-006 import/export surface (screen, controller, dry-run validation)
  // was granted to NO plan, so the sidebar never showed it. DATA-ONLY per the
  // 0042/0043 plan-grant block precedent: items.import_export joins business +
  // enterprise (starter keeps manual entry; BR-040 closure deps already in
  // place); zero new tables/columns/enums/journals/permission keys (INV-022;
  // drift stays 245=245); idempotent array_cat guard.
  "0048_items_import_export_grant",
  // PHASE-036 (Blueprint v3.0 · CR-06): 0049_custom_fields — the
  // extensibility core per ADR-0019 / FD-18/FD-19/FD-20 + DF-39: five
  // RLS'd tenant tables (custom_field_definitions + the TYPED value store
  // custom_field_values with the num_nonnulls one-typed-column law +
  // custom_picklists/custom_picklist_options with archive-preserving
  // history + form_layouts with the two partial uniques for default/role
  // layouts), the three §3.8 permission seeds (drift 245 → 248) + the
  // accountant read grant, and the platform.custom_fields plan grant
  // (business + enterprise — the tier-4 precedent; starter excluded).
  // NOT ledger documents — zero journal rules by construction.
  "0049_custom_fields",
  // PHASE-037 (Blueprint v3.0 · CR-07): 0050_zatca_phase1 — the ZATCA
  // Phase-1 GENERATION substrate (H-01 Phase-1 / H-02): additive NULLABLE
  // sales_invoices columns (zatca_device_id / icv / previous_invoice_hash /
  // invoice_hash / invoice_hash_version / qr_payload / classification +
  // the partial unique (tenant, device, icv) INV-027 floor + the
  // EXPLAIN-verified chain-walk index), and the RLS'd zatca_devices
  // registry (NOT_REGISTERED-only in Phase-1 — BR-061; icv_counter is the
  // chain anchor). One permission seed (tax.einvoicing.devices.manage —
  // drift 248 → 249). NOT ledger documents — the stamp rides the
  // invoice's own post transaction; zero journal rules.
  "0050_zatca_phase1",
];

/**
 * Module-system independent resolution (tsc CJS __dirname vs vitest ESM):
 * prefer the package-local `migrations/` of the invoking workspace, then the
 * monorepo-root-relative path for callers at other cwds.
 */
function resolveMigrationsDir(): string {
  const candidates = [
    join(process.cwd(), "migrations"),
    join(process.cwd(), "apps", "api", "migrations"),
  ];
  for (const candidate of candidates) {
    if (existsSync(join(candidate, "meta", "_journal.json"))) {
      return candidate;
    }
  }
  return candidates[0]!;
}

export const MIGRATIONS_DIR: string = resolveMigrationsDir();

export interface MigrationFile {
  tag: string;
  content: string;
}

/** Reads and returns every migration SQL file in manifest order. */
export function readMigrationFiles(): MigrationFile[] {
  const files = readdirSync(MIGRATIONS_DIR)
    .filter((name) => /^\d{4}_.+\.sql$/.test(name))
    .sort();
  const tags = files.map((name) => name.replace(/\.sql$/, ""));
  if (tags.join(",") !== MIGRATIONS.join(",")) {
    throw new Error(
      `Migration drift: manifest [${MIGRATIONS.join(", ")}] vs files [${tags.join(", ")}]`,
    );
  }
  return files.map((name, index) => ({
    tag: tags[index]!,
    content: readFileSync(join(MIGRATIONS_DIR, name), "utf8"),
  }));
}
